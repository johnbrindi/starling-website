JUTHELINK - ROUTER KIT

UPLOAD to the router:
  hotspot/login.html, hotspot/alogin.html, hotspot/status.html -> into the router's hotspot folder
  starling-profiles.rsc -> top level (replace), then: /import file-name=starling-profiles.rsc  (adds the free 'family' package)
KEEP ON YOUR PC: ticket-maker.html (double-click), the PDF

MTN MoMo: *126*9*677358806*amount#   WhatsApp: 673727995
